package enums;

public enum ActionEvenement {
	AJOUT,
	CONSULTATION,
	MODIFICATION;
}
