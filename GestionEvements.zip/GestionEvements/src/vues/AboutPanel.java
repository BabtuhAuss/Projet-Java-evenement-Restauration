package vues;

import javafx.scene.Group;

public class AboutPanel extends Group {
	
	/**
	 * Une r�f�rence � la fen�tre principale
	 */
	final FenetrePrincipale fenetrePrincipale;
	
	public AboutPanel(final FenetrePrincipale fenetrePrincipale) {
		this.fenetrePrincipale = fenetrePrincipale;
		
		
	}
}
